# overpython
Overcomplicated Python. Kinda pointless.
I got bored, so I made this pointless project.

Aside from overcomplicating Python, it also adds a few new functions such as newFile() and printnl().
There are a few things that completely defeat the purpose of overcomplicating Python, such as `from overpython import *`
# Installation
There's no official PyPi package right now. So just do the following:
  1. Download overpython as a zip file.
  2. Put overpython.py in a folder.
  3. Type `import overpython` as the first line
  4. Enjoy your abomination!
# Example code
```py
import overpython

overpython.clear()
overpython.println("Sir, can i have your name?")
name = overpython.get("Name: ")
name = overpython.tolower(name)
if overpython.equals(name, "John"):
    overpython.println("Sorry John, you're going to jail son.")
else:
    overpython.println("Thanks, " + overpython.tolower(name))
overpython.pause()
```
Output:
```
Hello my habibi 489
Press the ENTER key to exit...
```